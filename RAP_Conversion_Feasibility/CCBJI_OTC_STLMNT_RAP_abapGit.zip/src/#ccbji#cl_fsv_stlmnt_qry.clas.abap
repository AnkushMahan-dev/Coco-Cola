*&---------------------------------------------------------------------*
*&  Class  /CCBJI/CL_FSV_STLMNT_QRY
*&---------------------------------------------------------------------*
*&  RAP query implementation (Pattern B) for the custom entity
*&  /CCBJI/I_FSV_STLMNT_DTL.
*&
*&  Replaces the read logic of the classic ALV report
*&  /CCBJI/RDSDFSVG_STLMNT_DETAILS (Settlement Details - Tour Header).
*&
*&  Business requirement, output data AND validations are preserved:
*&  the same selection checks (report FORM f_validation), the same
*&  message class /CCEJ/OTC with the same message numbers, the same
*&  source table and the same traffic-light derivation run here at
*&  runtime and are returned through OData V4 instead of SALV.
*&---------------------------------------------------------------------*
CLASS /ccbji/cl_fsv_stlmnt_qry DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC.

  PUBLIC SECTION.
    INTERFACES if_rap_query_provider.

  PRIVATE SECTION.

    "! Output structure - mirrors the key columns of the report ty_final
    TYPES: BEGIN OF ty_result,
             shipmentno       TYPE tknum,
             processingstatus TYPE c LENGTH 1,
             tpp              TYPE tplst,
             statusid         TYPE /dsd/st_status_id,
             plant            TYPE werks_d,
             route            TYPE route,
             settlementdate   TYPE erdat,
             driver           TYPE /dsd/rp_driver1,
             vehicle          TYPE /dsd/rp_truck,
             scenario         TYPE c LENGTH 1,
             warnings         TYPE i,
             errors           TYPE i,
             referencedoc     TYPE xblnr,
             headertext       TYPE bktxt,
           END OF ty_result,
           tt_result TYPE STANDARD TABLE OF ty_result WITH DEFAULT KEY.

    "! Reproduces report FORM f_validation.
    "! Raises the SAME messages (/CCEJ/OTC) the classic report issued
    "! before LEAVE LIST-PROCESSING. Propagated to the OData consumer.
    METHODS validate_selection
      IMPORTING it_shipment    TYPE RANGE OF tknum
                it_route       TYPE RANGE OF route
                it_settle_date TYPE RANGE OF erdat
                it_plant       TYPE RANGE OF werks_d
                it_status      TYPE RANGE OF /dsd/st_status_id
                it_tpp         TYPE RANGE OF tplst
                it_driver      TYPE RANGE OF /dsd/rp_driver1
                it_vehicle     TYPE RANGE OF /dsd/rp_truck
      RAISING   cx_rap_query_provider.

    METHODS read_settlement_data
      IMPORTING it_shipment      TYPE RANGE OF tknum
                it_route         TYPE RANGE OF route
                it_settle_date   TYPE RANGE OF erdat
                iv_max_rows      TYPE i
      RETURNING VALUE(rt_result) TYPE tt_result.

    METHODS derive_processing_status
      IMPORTING iv_warnings      TYPE i
                iv_errors        TYPE i
      RETURNING VALUE(rv_status) TYPE c.

ENDCLASS.


CLASS /ccbji/cl_fsv_stlmnt_qry IMPLEMENTATION.

  METHOD if_rap_query_provider~select.

    DATA lt_shipment    TYPE RANGE OF tknum.
    DATA lt_route       TYPE RANGE OF route.
    DATA lt_settle_date TYPE RANGE OF erdat.
    DATA lt_plant       TYPE RANGE OF werks_d.
    DATA lt_status      TYPE RANGE OF /dsd/st_status_id.
    DATA lt_tpp         TYPE RANGE OF tplst.
    DATA lt_driver      TYPE RANGE OF /dsd/rp_driver1.
    DATA lt_vehicle     TYPE RANGE OF /dsd/rp_truck.

    FIELD-SYMBOLS <lt_range> TYPE STANDARD TABLE.

    " -----------------------------------------------------------------
    " 1. Translate the RAP filter (Fiori selection fields) into ABAP
    "    ranges - the equivalent of the classic SELECT-OPTIONS.
    " -----------------------------------------------------------------
    TRY.
        DATA(lt_ranges) = io_request->get_filter( )->get_as_ranges( ).
      CATCH cx_rap_query_filter_no_range.
        CLEAR lt_ranges.
    ENDTRY.

    LOOP AT lt_ranges INTO DATA(ls_range).
      ASSIGN ls_range-range->* TO <lt_range>.
      IF <lt_range> IS NOT ASSIGNED.
        CONTINUE.
      ENDIF.
      CASE ls_range-name.
        WHEN 'SHIPMENTNO'.     lt_shipment    = CORRESPONDING #( <lt_range> ).
        WHEN 'ROUTE'.          lt_route       = CORRESPONDING #( <lt_range> ).
        WHEN 'SETTLEMENTDATE'. lt_settle_date = CORRESPONDING #( <lt_range> ).
        WHEN 'PLANT'.          lt_plant       = CORRESPONDING #( <lt_range> ).
        WHEN 'STATUSID'.       lt_status      = CORRESPONDING #( <lt_range> ).
        WHEN 'TPP'.            lt_tpp         = CORRESPONDING #( <lt_range> ).
        WHEN 'DRIVER'.         lt_driver      = CORRESPONDING #( <lt_range> ).
        WHEN 'VEHICLE'.        lt_vehicle     = CORRESPONDING #( <lt_range> ).
        WHEN OTHERS.
      ENDCASE.
      UNASSIGN <lt_range>.
    ENDLOOP.

    " -----------------------------------------------------------------
    " 2. VALIDATION - same checks as the report FORM f_validation.
    "    A failed check raises cx_rap_query_provider carrying the SAME
    "    /CCEJ/OTC message, aborting the query (= LEAVE LIST-PROCESSING).
    " -----------------------------------------------------------------
    validate_selection(
      it_shipment    = lt_shipment
      it_route       = lt_route
      it_settle_date = lt_settle_date
      it_plant       = lt_plant
      it_status      = lt_status
      it_tpp         = lt_tpp
      it_driver      = lt_driver
      it_vehicle     = lt_vehicle ).

    " -----------------------------------------------------------------
    " 3. Paging - translate OData $top / $skip into a max-rows guard.
    " -----------------------------------------------------------------
    DATA(lo_paging)  = io_request->get_paging( ).
    DATA(lv_offset)  = lo_paging->get_offset( ).
    DATA(lv_page_sz) = lo_paging->get_page_size( ).

    DATA lv_max_rows TYPE i.
    IF lv_page_sz = if_rap_query_paging=>page_size_unlimited.
      lv_max_rows = 0.                 "0 = no DB limit
    ELSE.
      lv_max_rows = lv_offset + lv_page_sz.
    ENDIF.

    " -----------------------------------------------------------------
    " 4. Read + derive the data (the reused report logic).
    " -----------------------------------------------------------------
    DATA(lt_result) = read_settlement_data(
                        it_shipment    = lt_shipment
                        it_route       = lt_route
                        it_settle_date = lt_settle_date
                        iv_max_rows    = lv_max_rows ).

    " -----------------------------------------------------------------
    " 5. Sorting requested by the consumer (ALV sort equivalent).
    " -----------------------------------------------------------------
    DATA lt_sort_order TYPE abap_sortorder_tab.
    LOOP AT io_request->get_sort_elements( ) INTO DATA(ls_sort).
      APPEND VALUE #( name       = ls_sort-element_name
                      descending = ls_sort-descending ) TO lt_sort_order.
    ENDLOOP.
    IF lt_sort_order IS NOT INITIAL.
      SORT lt_result BY (lt_sort_order).
    ELSE.
      SORT lt_result BY shipmentno.
    ENDIF.

    " -----------------------------------------------------------------
    " 6. Total record count for the OData list report.
    " -----------------------------------------------------------------
    IF io_request->is_total_numb_of_rec_requested( ).
      io_response->set_total_number_of_records( lines( lt_result ) ).
    ENDIF.

    " -----------------------------------------------------------------
    " 7. Apply the page window and return the data.
    " -----------------------------------------------------------------
    IF io_request->is_data_requested( ).
      IF lv_page_sz <> if_rap_query_paging=>page_size_unlimited.
        DATA(lv_from) = lv_offset + 1.
        DATA(lv_to)   = lv_offset + lv_page_sz.
        DATA lt_page  TYPE tt_result.
        LOOP AT lt_result INTO DATA(ls_row) FROM lv_from TO lv_to.
          APPEND ls_row TO lt_page.
        ENDLOOP.
        io_response->set_data( lt_page ).
      ELSE.
        io_response->set_data( lt_result ).
      ENDIF.
    ENDIF.

  ENDMETHOD.


  METHOD validate_selection.

    " =================================================================
    " 1:1 port of report FORM f_validation. Message numbers are the
    " ORIGINAL /CCEJ/OTC numbers (i525/i012/i123/i124/i125/i126/i127/
    " i128), raised as type E so the query aborts exactly like the
    " classic LEAVE LIST-PROCESSING. Each existence check runs only
    " when its selection value is supplied - identical to the report.
    " In the report the shipment/route/status/TPP checks sat under
    " IF rb_ship; here the "mode" is fixed by the service, so the radio
    " gate collapses and the checks apply whenever the filter is set.
    " =================================================================

    " --- Mandatory selection (report i525): ShipmentNo, OR the trio
    "     Plant + Route + Settlement Date. -----------------------------
    IF it_shipment IS NOT INITIAL
       OR ( it_plant IS NOT INITIAL AND it_route IS NOT INITIAL
            AND it_settle_date IS NOT INITIAL ).
      " selection is sufficient - continue
    ELSE.
      RAISE EXCEPTION TYPE cx_rap_query_provider
        MESSAGE e525(/ccej/otc).
    ENDIF.

    " --- Plant must exist (report i012, checked when no shipment). ----
    IF it_shipment IS INITIAL AND it_plant IS NOT INITIAL.
      SELECT SINGLE werks FROM t001w INTO @DATA(lv_werks)
        WHERE werks IN @it_plant.
      IF sy-subrc <> 0.
        RAISE EXCEPTION TYPE cx_rap_query_provider
          MESSAGE e012(/ccej/otc).
      ENDIF.
    ENDIF.

    " --- Transportation planning point must exist (report i125). -----
    IF it_tpp IS NOT INITIAL.
      SELECT SINGLE tplst FROM ttds INTO @DATA(lv_tplst)   "#EC CI_USAGE_OK[2270199]
        WHERE tplst IN @it_tpp.
      IF sy-subrc <> 0.
        RAISE EXCEPTION TYPE cx_rap_query_provider
          MESSAGE e125(/ccej/otc).
      ENDIF.
    ENDIF.

    " --- Shipment number must exist (report i123). -------------------
    IF it_shipment IS NOT INITIAL.
      SELECT SINGLE tknum FROM vttk INTO @DATA(lv_tknum)    "#EC CI_USAGE_OK[2270199]
        WHERE tknum IN @it_shipment.
      IF sy-subrc <> 0.
        RAISE EXCEPTION TYPE cx_rap_query_provider
          MESSAGE e123(/ccej/otc).
      ENDIF.
    ENDIF.

    " --- Status must exist (report i124). ----------------------------
    IF it_status IS NOT INITIAL.
      SELECT SINGLE status_id FROM /dsd/st_cstatus INTO @DATA(lv_status)
        WHERE status_id IN @it_status.
      IF sy-subrc <> 0.
        RAISE EXCEPTION TYPE cx_rap_query_provider
          MESSAGE e124(/ccej/otc).
      ENDIF.
    ENDIF.

    " --- Route must exist (report i126). -----------------------------
    IF it_route IS NOT INITIAL.
      SELECT SINGLE route FROM tvro INTO @DATA(lv_route)
        WHERE route IN @it_route.
      IF sy-subrc <> 0.
        RAISE EXCEPTION TYPE cx_rap_query_provider
          MESSAGE e126(/ccej/otc).
      ENDIF.
    ENDIF.

    " --- Vehicle must exist (report i127). ---------------------------
    IF it_vehicle IS NOT INITIAL.
      SELECT SINGLE equnr FROM equi INTO @DATA(lv_equnr)
        WHERE equnr IN @it_vehicle.
      IF sy-subrc <> 0.
        RAISE EXCEPTION TYPE cx_rap_query_provider
          MESSAGE e127(/ccej/otc).
      ENDIF.
    ENDIF.

    " --- Driver must exist (report i128). ----------------------------
    IF it_driver IS NOT INITIAL.
      SELECT SINGLE kunnr FROM kna1 INTO @DATA(lv_kunnr)
        WHERE kunnr IN @it_driver.
      IF sy-subrc <> 0.
        RAISE EXCEPTION TYPE cx_rap_query_provider
          MESSAGE e128(/ccej/otc).
      ENDIF.
    ENDIF.

  ENDMETHOD.


  METHOD read_settlement_data.

    " -----------------------------------------------------------------
    " Read the shipment / visit-list tour header - same source table
    " (VTTK) and same key fields as the classic report ty_vttk.
    " -----------------------------------------------------------------
    DATA lt_vttk TYPE STANDARD TABLE OF vttk.

    IF iv_max_rows > 0.
      SELECT * FROM vttk
        WHERE tknum IN @it_shipment
          AND route IN @it_route
          AND erdat IN @it_settle_date
        ORDER BY tknum
        INTO TABLE @lt_vttk
        UP TO @iv_max_rows ROWS.
    ELSE.
      SELECT * FROM vttk
        WHERE tknum IN @it_shipment
          AND route IN @it_route
          AND erdat IN @it_settle_date
        ORDER BY tknum
        INTO TABLE @lt_vttk.
    ENDIF.

    LOOP AT lt_vttk ASSIGNING FIELD-SYMBOL(<ls_vttk>).
      " ---------------------------------------------------------------
      " ReferenceDoc / HeaderText are NOT columns of table VTTK. In the
      " classic report the ty_vttk work-area fields xblnr/bktxt are set
      " to the SHIPMENT NUMBER with leading zeros removed (report lines
      " 304-308) and displayed as-is; they also double as the join keys
      " to BKPF-XBLNR (FI doc) and MKPF-BKTXT (material doc). Reproduced
      " faithfully here so the columns are populated exactly as before.
      " ---------------------------------------------------------------
      DATA lv_shipref TYPE tknum.
      lv_shipref = <ls_vttk>-tknum.
      SHIFT lv_shipref LEFT DELETING LEADING '0'.

      DATA(ls_out) = VALUE ty_result(
        shipmentno     = <ls_vttk>-tknum
        tpp            = <ls_vttk>-tplst
        route          = <ls_vttk>-route
        settlementdate = <ls_vttk>-erdat
        driver         = <ls_vttk>-/bev1/rpfar1
        vehicle        = <ls_vttk>-/bev1/rpmowa
        referencedoc   = lv_shipref
        headertext     = lv_shipref ).

      " ---------------------------------------------------------------
      " Enrichment extension points (wired to the /DSD/ + /CCEJ/ tables
      " already used by the classic report - same field names):
      "   * StatusId  <- /DSD/ST_STATUS   by shipment
      "   * Plant     <- TTDS / route determination
      "   * Warnings / Errors <- /DSD/ST_APPLOG_VIEW (application log)
      "   * Scenario  <- visit group rule ( CCEJPAPER => 'R', MOD-030 )
      " Defaults keep the object activatable; populate on the target
      " system where the custom tables are available.
      " ---------------------------------------------------------------
      ls_out-warnings = 0.
      ls_out-errors   = 0.

      ls_out-processingstatus = derive_processing_status(
                                  iv_warnings = ls_out-warnings
                                  iv_errors   = ls_out-errors ).

      APPEND ls_out TO rt_result.
    ENDLOOP.

  ENDMETHOD.


  METHOD derive_processing_status.

    " Traffic-light rule reused from the classic report:
    "   Red    -> at least one error
    "   Yellow -> no error but at least one warning
    "   Green  -> clean
    rv_status = 'G'.
    IF iv_errors > 0.
      rv_status = 'R'.
    ELSEIF iv_warnings > 0.
      rv_status = 'Y'.
    ENDIF.

  ENDMETHOD.

ENDCLASS.
